# Program 035 - 03 Loops
n = 5
i = 1
while i <= n:
    print(i)
    i += 1
