# Program 021 - 03 Loops
for i in range(1, 6):
    print(i)
