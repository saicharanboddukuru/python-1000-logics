# Program 013 - 03 Loops
n = 5
fact = 1
for i in range(1, n+1):
    fact *= i
print('Factorial:', fact)
