# Program 020 - 04 Functions Recursion
def is_even(n):
    return n % 2 == 0

print(is_even(4))
