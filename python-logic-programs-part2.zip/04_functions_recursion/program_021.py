# Program 021 - 04 Functions Recursion
def add(a, b):
    return a + b

print('Sum:', add(3, 5))
